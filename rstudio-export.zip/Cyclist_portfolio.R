# Client: Cyclist Bike Sharing
# Objective: To maximise the number of annual subcriptions for Cyclist

# Problem statement: How differently do casual bikers and annual subsribers use Cyclist services and how can we 
# effectively market to casual biker in order to convert them to annual subscribers?

# Overview: Cyclist is a bike sharing company based in Chicago, USA, with annual memberships and one-time passes.
# Casual riders buy daily or one-way passes while members pay yearly, and members are more profitable

# Data Preparation
# Installing packages, data etc.

install.packages("tidyverse")
library(tidyverse)
install.packages("ggplot2")
library(ggplot2)

Trips_in_2019 <- read_csv("Divvy_Trips_2019_Q1 - Divvy_Trips_2019_Q1.csv")
Trips_in_2020 <- read_csv("Divvy_Trips_2020_Q1 - Divvy_Trips_2020_Q1.csv")

# Data wrangling/cleaning
# Making consistent column name for both tables

Trips_in_2020 <- Trips_in_2020 %>%
  rename(trip_id = ride_id,
         start_time = started_at,
         end_time = ended_at,
         from_station_name = start_station_name,
         to_station_name = end_station_name,
         usertype = member_casual,
         from_station_id = start_station_id,
         to_station_id = end_station_id)

# Combining tables

Trips_combined <- bind_rows(
  Trips_in_2019 %>% mutate(year = "2019", trip_id = as.character(trip_id)),
  Trips_in_2020 %>% mutate(year = "2020", trip_id = as.character(trip_id))
)

# Unifying dates
Trips_combined <- Trips_combined %>%
  mutate(start_time = ymd_hms(start_time),
         end_time = ymd_hms(end_time)
  )

# Calculate trip duration
Trips_combined <- Trips_combined %>% 
  mutate(tripduration = as.numeric(difftime(end_time,start_time)))

# Make usertype consistent
Trips_combined <- Trips_combined %>%
  mutate(usertype = case_when(
    usertype == "Subscriber" ~ "member",
    usertype == "Customer" ~ "casual",
    usertype == "member" ~ "member",      
    usertype == "casual" ~ "casual",      
    TRUE ~ usertype
  ))

# Add trip day for analysis purposes
Trips_combined <- Trips_combined %>%
  mutate(dayofweek = wday(start_time, label = TRUE))

# Filter table/ data validation
Cleanedtable <- Trips_combined %>%
  filter(!is.na(tripduration) & tripduration > 0,
         )

Cleanedtable <- Cleanedtable %>%
  select(trip_id, start_time, end_time,tripduration, from_station_id, from_station_name, to_station_id, to_station_name, usertype,year, dayofweek)

Cleanedtable <- Cleanedtable %>%
  mutate(tripduration_minutes = tripduration/60)
  
#Visualise table using ggplot
## Summarise by usertype

Summary_byuser <- Cleanedtable %>%
  group_by(usertype) %>%
  summarise(
    trip_id = n(), 
    average_duration = mean(tripduration_minutes, na.rm = TRUE)
  )
## Summarise by day
Summarise_byday <- Cleanedtable %>%
  group_by(dayofweek, usertype) %>%
  summarise(trip_id = n())

# Plot

## Count trips by usertype and day of week
ggplot(Summary_byuser, aes(x = usertype, y = average_duration, fill =
                              usertype)) +
  geom_col(show.legend = FALSE) +
  labs(x = "User Type", y = "Avg Trip Length (min)",
       title = "Average Trip Length by User Type") +
  theme_minimal()



# Trip by day of the week
ggplot(Summarise_byday, aes(x = dayofweek, y = trip_id, fill =
                               usertype)) +
  geom_col(position = "dodge") +
  labs(x = "Day of Week", y = "Number of Rides",
       title = "Daily Trips by User Type", fill = "User Type") +
  theme_minimal()

